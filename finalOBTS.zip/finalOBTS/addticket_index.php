<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>
<head>
<title>Online Bus Ticket System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script type='text/javascript' src='//code.jquery.com/jquery-1.8.3.js'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker3.min.css">
    <script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="assets/bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="assets/bootstrap-timepicker/js/bootstrap-timepicker.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script type='text/javascript'>
$('.timepicker-default').timepicker();
</script>

</head>

<style>
body, html {
    height: 100%;
    background-repeat: no-repeat;
    background-image: url('back.jpg');
}
</style>

<body>
 <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home_index.php">Online Bus Ticket Admin System</a>
    </div>
	<div class="collapse navbar-collapse">
    <ul class="nav navbar-nav">
	   <li class="dropdown">
        <a class="dropdown-toggle" class="active" data-toggle="dropdown">Add
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="addvoyage_index.php">Voyage</a></li>
          <li><a href="addbus_index.php">Bus</a></li>
		  <li><a href="addticket_index.php">Ticket</a></li>
		  <li><a href="addcity_index.php">City</a></li>
        </ul>
      </li>
      <li class="dropdown">
	   <a class="dropdown-toggle" data-toggle="dropdown" >Delete
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
           <li><a href="deletevoyage_index.php">Voyage</a></li>
		  <li><a href="deletebus_index.php">Bus</a></li>
		  <li><a href="deleteticket_index.php">Ticket</a></li>

        </ul>
      </li>
	   <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" >Edit
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="editvoyage.php">Voyage</a></li>
        </ul>
      </li>
	    <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" >View
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="viewvoyage.php">Voyage</a></li>
		  <li><a href="viewticket.php">Ticket</a></li>
          <li><a href="viewbus.php">Bus</a></li>
		  <li><a href="viewcity.php">City</a></li>
        </ul>
      </li>
	  
	  
	   </ul>
    <ul class="nav navbar-nav navbar-right">
     
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
    </ul>
	

  </div>
</nav>
  <div class="form">
 
   <div class=" col-md-4 col-md-offset-4">
        	<div class="panel panel-default"  >
        		<div class="panel-heading">
			    		<h3 class="panel-title">Add Ticket Form </h3>
			 			</div>
						<div class="panel-body">
			   
			   <div class="row">
												
						
	<form id="bootstrapSelectForm" method="post" class="form-horizontal" action="addticket.php">
	 <?php
	 if (isset($_GET["msg"]) && $_GET["msg"] == 'succes') {
						  ?>
						  <div class="alert alert-success">
						 
  <strong>Success!</strong> 
</div>
<?php
                     
                             }
?>


<?php
					  if (isset($_GET["msg"]) && $_GET["msg"] == 'failed') {
						  ?>
						  <div class="alert alert-danger">
  <strong>The voyage is added!</strong> Please retry.
</div>
<?php
                     
                             }
?>

<?php
					$sql=mysql_query("SELECT * FROM voyage ORDER BY voyage_id ASC");
$optionvoyage = '';
 while($row = mysql_fetch_assoc($sql))
{
  $optionvoyage .= '<option value = "'.$row['voyage_id'].'">'.$row['voyage_id'].'</option>';
}
?>
   <div class="form-group" >
        <label class="col-xs-3 control-label">Voyage id</label>
        <div class="col-xs-5 selectContainer">
			
	
            <select class="form-control"  name="voyage" style="width: 155%"  oninvalid="this.setCustomValidity('Please choose a voyage ')"
 oninput="setCustomValidity('')"   required>
			<option selected disabled> </option>
                <?php echo $optionvoyage; ?>
            </select>
        </div>
    </div>
	
	
<div class="form-group" >
	 <label class="col-xs-3 control-label">Time &nbsp;</label>
	 <div class="col-xs-5 selectContainer">
            <input id="appt-time" type="time" name="time" step="2"  required>
                <i class="glyphicon glyphicon-time"></i>
        </div>
	  </div>
	  
	  
	  

	<!--	 <input type="text" name="time" placeholder="time" class="form-control" oninvalid="this.setCustomValidity('Please choose a voyage date')"
 oninput="setCustomValidity('')"   required>
        </div>
        </div>
		-->
    
	
	 


	 <div class="form-group"   >
        <label class="col-xs-3 control-label">Amount</label>
        <div class="col-xs-5 selectContainer">
		 <input type="text" name="amount" placeholder="amount" class="form-control" oninvalid="this.setCustomValidity('Please enter amount')"
 oninput="setCustomValidity('')"   required>
        </div>
    </div>
   
   
<div class="form-group" >
 <div class="col-sm-offset-8 col-sm-10">
   <input type="submit" name="add" class="btn btn-primary" value="Submit" >
   </div>
   </div>
              </div>
                </form>
            </div>
        </div>
    </div>
	</div>

	
</body>
</html>