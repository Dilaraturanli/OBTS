<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
	
}

?>
<title>Online Bus Ticket System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<style>
body, html {
    height: 150%;
    background-repeat: no-repeat;
    background-image: url('back.jpg');

    background-position: center;

    background-size: cover;
}
</style>
<body>
  <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home_index.php">Online Bus Ticket Admin System</a>
    </div>
	<div class="collapse navbar-collapse">
    <ul class="nav navbar-nav">
	   <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown">Add
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="addvoyage_index.php">Voyage</a></li>
          <li><a href="addbus_index.php">Bus</a></li>
		  <li><a href="addticket_index.php">Ticket</a></li>
		  <li><a href="addcity_index.php">City</a></li>
        </ul>
      </li>
      <li class="dropdown">
	   <a class="dropdown-toggle" class="active"  data-toggle="dropdown" >Delete
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
           <li><a href="deletevoyage_index.php">Voyage</a></li>
		  <li><a href="deletebus_index.php">Bus</a></li>
		  <li><a href="deleteticket_index.php">Ticket</a></li>

        </ul>
      </li>
	   <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" >Edit
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="editvoyage.php">Voyage</a></li>
        </ul>
      </li>
	    <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" >View
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="viewvoyage.php">Voyage</a></li>
		  <li><a href="viewticket.php">Ticket</a></li>
          <li><a href="viewbus.php">Bus</a></li>
		  <li><a href="viewcity.php">City</a></li>
        </ul>
      </li>
	  
	  
	   </ul>
    <ul class="nav navbar-nav navbar-right">
     
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
    </ul>
	

  </div>
</nav>

<div class="container" >
 <div class="form">
    <form action="deletevoyage.php" method="post">		  
 <div class="panel panel-default">
        		<div class="panel-heading">
			    		<h3 class="panel-title">Voyage List</h3>
			 			</div>
						<div class="panel-body">
<table class="table  table-bordered" id="data">
 <thead>
 <tr>
 <th>  </th>
 <th>Voyage ID</th>
 <th>Bus Model</th>
 <th>Starting Location</th>
  <th>Destination Location </th>
   <th> Voyage Date</th>
 </tr>
 </thead>
 <tbody>
 <tr>
 <?php
 
   include("database.php"); 
   
    
	   $voyage=mysql_query("SELECT * from voyage");
		  $length=count($voyage);
		
while($sql=mysql_fetch_array($voyage)){
	
echo '<td><input type="radio" name="voyageid[]" value="'.@$sql[voyage_id].'"  ></td>';
 echo"<td>".$sql['voyage_id']."</td>";
 $busmodel=mysql_query("SELECT * from bus where bus_id='$sql[bus_id]'");
 $bm=mysql_fetch_array($busmodel);
 echo"<td>".$bm['bus_model']."</td>";
 
 $startingLocation=mysql_query("SELECT * from city where city_id='$sql[startingLocation]'");
 $sl=mysql_fetch_array($startingLocation);
 echo"<td>".$sl['city_name']."</td>";
 
  $destinationLocation=mysql_query("SELECT * from city where city_id='$sql[destinationLocation]'");
 $dl=mysql_fetch_array($destinationLocation);
 echo"<td>".$dl['city_name']."</td>";
 echo"<td>".$sql['voyage_date']."</td>";
 
 
  
 echo "</tr>"; 
 
 }
 
 
?>


 <tbody> 
</table>
<input type="submit" name="deletevoyage" value="Delete" class="btn btn-info btn-block"  style="height:60px; width:100px; float: right">
 </form>
</body>
</div>
 </div>
 </div>
 </div>
 </div>
 </div>
