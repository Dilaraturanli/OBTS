<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>



<?php
if($_POST["add"]){

	$busmodel=$_POST["busmodel"];
		$numofseats=$_POST["numofseats"];
	   include("database.php"); 
	   	
	   	   
         $sql = mysql_num_rows(mysql_query("SELECT * FROM bus WHERE   bus_model='$busmodel' "));
		
		if ($sql==0){
		 mysql_query("insert into bus(bus_id,bus_model,numberofseats) VALUES (NULL,'$busmodel','$numofseats')");
		  header("location:addbus_index.php?msg=succes");
	    }
		
	   else{
		 header("location:addbus_index.php?msg=failed");
		
		
		}
		
		

	   
  
 
 }
?>