

<head>
<title>Online Bus Ticket System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script type='text/javascript' src='//code.jquery.com/jquery-1.8.3.js'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker3.min.css">
    <script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.min.js"></script>
        <link rel="stylesheet" href="css/bus.css">
		
  
</head>
<style>
body, html {
    height: 100%;
    background-repeat: no-repeat;
    background-image: url('back.jpg');
}

.div1 {
    background-color : gray;
    width: 200px;
    height: 80px;
    border: 3px solid black;
    box-sizing: border-box;
	float:right; 
}


</style>



<body>
  <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">Online Bus Ticket System</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                     <li class="active"><a href="mainPage.php">MainPage</a></li>   
                    </ul>
                 
				  
				   <ul class="nav navbar-nav navbar-right">
                        <?php
                        if(isset($_SESSION["login"]))
                        {
                               
                          ?>
                          <li>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span>
                                Welcome <b> <span class="caret"></span></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo $personalPageLink; ?>">Personal Page</a></li>
                                <li><a href="<?php echo $personalChangePass; ?>">Change Password</a></li>
                            </ul>
                          </li>
                          <li>
                            <a href="userlogout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
                          </li>
                          <?php
                        }
                     
                        ?>
                    </ul>
			</div>  
       </nav>

<?php
if (empty($_POST["seat2"]) ){
	  ?>
	  <div class="row">
	  <div class="col-md-4 col-md-offset-4">
						  <div class="alert alert-danger">
  <strong></strong> Please choose a seat
</div>
</div>
</div>
<?php
                     
}
?>


<?php							 

if($_POST["continue"] AND !empty($_POST["seat2"]) ){
 $seat2=$_POST["seat2"];
	$length=count($seat2);
	$amount=$_POST["amount"];
	$ticket_id=$_POST["ticket_id"];
	   include("database.php"); 
	   session_start();
	?>
 <div class="form group">
  <form action='payment.php' method="post">
<div class="container" >
 <div class="panel panel-default">
        		<div class="panel-heading">
			    		<h3 class="panel-title">Ticket Informations</h3>
			 			</div>
						<div class="panel-body">
<table class="table  table-bordered" id="data">
 <thead>
 <tr>
 <th>Seat number</th>
 <th>SSN number</th>
 <th>Name</th>
 <th>Last Name</th> 
 <th>Amount</th> 

 </tr>
 </thead>
 <tbody>
 <tr>
 <?php	

 
 for($i=0; $i<$length;$i++){
	 echo '<td><input type="text" readonly="readonly" name="seatnum[]" value="'.$seat2[$i].' "  required ></td>';

?>

 <?php
  echo"<td>"?>
  
  <input type="text"   name="ssn[]"  placeholder="ssn number" class="form-control" pattern="[0-9]{11}"  required>
  <?php
   "</td>";
    echo"<td>"?>
  <input type="text" name="name"  placeholder="name" class="form-control" required>
  <?php
   "</td>";
    echo"<td>"?>
  <input type="text" name="lastname"  placeholder="last name" class="form-control" required>
  <?php
   "</td>";
   

  echo"<td>".$amount."</td>";
echo "</tr>"; 
	   }
	   
$tamount=0;
 for($j=0; $j<$i;$j++){
	$tamount += $amount;
 }


	
?>
<input type="hidden" name="tamount" value="<?php echo $tamount;?>">
<input type="hidden" name="ticket_id" value="<?php echo $ticket_id;?>">
<input type="hidden" name="length" value="<?php echo $length;?>">
</table>
<div class="div1"><h3>Total amount:<?php echo $tamount;?></h3> </div>
<br><br><br>
<br>
<br>

<div class="form-group" >  
<input type="submit" name="payment" value="Payment" class="btn btn-info btn-block"  style="height:60px; width:100px; float: right">
</div>
 </div>
</div>

<?php
}

?>
