<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>



<?php
if($_POST["add"]){

	$voyage=$_POST["voyage"];
	$time=$_POST["time"];
		$amount=$_POST["amount"];
		
	$time = date("H:i:s",strtotime($time));
	   include("database.php"); 
	   	
	   	   
         $sql = mysql_query("SELECT * FROM voyage WHERE   voyage_id='$voyage'");
		 $row = mysql_fetch_array($sql) ;
		 $voyage_id=$row[0];
		 
	    $busid=mysql_query("select bus_id from voyage where voyage_id= '$voyage_id'");
		
		$r= mysql_fetch_array($busid);
		$bus_id= $r[0];
		 
		$numofseat=mysql_query("select numberofseats from bus where bus_id= '$bus_id'");
		$b= mysql_fetch_array($numofseat);
		$num_seat= $b[0];
		
		
		 mysql_query("insert into ticket (ticket_id,voyage_id,time,seat,amount) VALUES (NULL,'$voyage_id','$time','$num_seat','$amount')");
		
		}
		
		

	   
  
 

?>