<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>

<?php
 include("database.php"); 
if($_POST["editvoyage"]){
	 $voyageid=$_POST["voyageid"];
	$startlocation=$_POST["startinglocation"];
	$destinationlocation=$_POST["destinationlocation"];
	

	
	  if ($startlocation==$destinationlocation){
			 header("location:editvoyage_index.php?msg=failed2");
			 exit;
		}
	$date=$_POST["date"];
	$date = date('Y-m-d', strtotime(str_replace('-', '/', $date)));
	
	
	
	$s=mysql_query("UPDATE voyage SET startinglocation='$startlocation' WHERE voyage_id=$voyageid");
       $s=mysql_query("UPDATE voyage SET destinationlocation='$destinationlocation' WHERE voyage_id=$voyageid");
	
	
  
 }
 
?>

