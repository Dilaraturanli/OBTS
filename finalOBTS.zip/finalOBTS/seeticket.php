<?php 

include("database.php");
ob_start();
session_start();



?>



<head>
<title>Online Bus Ticket System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script type='text/javascript' src='//code.jquery.com/jquery-1.8.3.js'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker3.min.css">
    <script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.min.js"></script>
        <link rel="stylesheet" href="css/bus.css">
		
		
  
</head>
<style>
body, html {
    height: 100%;
    background-repeat: no-repeat;
    background-image: url('back.jpg');
}
</style>



<body>
     <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">Online Bus Ticket System</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                     <li class="active"><a href="mainPage.php">MainPage</a></li>   
				
					 
                    </ul>
                 
				  
				   <ul class="nav navbar-nav navbar-right">
                        <?php
                        if(isset($_SESSION["login"]))
                        {
                               
                          ?>
                          <li>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span>
                                Welcome <b> <span class="caret"></span></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo $personalPageLink; ?>">Personal Page</a></li>
                                <li><a href="<?php echo $personalChangePass; ?>">Change Password</a></li>
                            </ul>
                          </li>
                          <li>
                            <a href="userlogout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
                          </li>
                          <?php
                        }
                     
                        ?>
                    </ul>
			</div>  
       </nav>
</nav>
 
  <div class="form group">
  
  
  <form action="selectseat_index.php" method="post">
 
<div class="container" >
 <div class="panel panel-default">
        		<div class="panel-heading">
			    		<h3 class="panel-title"> </h3>
			 			</div>
						<div class="panel-body">
<table class="table  table-bordered" id="data">
<?php
 if($_POST["buy"]){
          $startlocation=$_POST["startinglocation"];
	$destinationlocation=$_POST["destinationlocation"];
 }
	?>
 <thead>
 
 
 <tr>
  <?php
   $sl=mysql_query("SELECT * from city where city_id='$startlocation'");
 $sl=mysql_fetch_array($sl);

 
    $dl=mysql_query("SELECT * from city where city_id='$destinationlocation'");
 $dl=mysql_fetch_array($dl);

 ?>
  <div class="alert alert-success">
						 
  From <strong><?php  echo $sl[1]; ?></strong>  To <strong><?php  echo $dl[1]; ?> </strong> 
</div>

  
  <th> </th>
 <th>Voyage Time</th>
 
  <th>Bus Type</th>
 <th>Price</th>

</tr>


 </thead>
 <tbody>
 <tr>
 
 
 <?php
 
   include("database.php"); 
   
   if($_POST["buy"]){
          $startlocation=$_POST["startinglocation"];
	$destinationlocation=$_POST["destinationlocation"];
	 if ($startlocation==$destinationlocation){
			 header("location:mainPage.php?msg=failed2");
			 exit;
		}
	$date=$_POST["date"];
	$date = date('Y-m-d', strtotime(str_replace('-', '/', $date)));
	   
	   $vid=mysql_query("SELECT voyage_id from voyage WHERE    startingLocation='$startlocation'  AND destinationLocation='$destinationlocation' AND voyage_date='$date'");
		  $length=count($vid);
		   if($length==0){
			    
   header("location:mainPage.php?msg=failed");
		   }
 while($r=mysql_fetch_array($vid)){
 
		
		 $busid=mysql_query("SELECT bus_id from voyage WHERE  voyage_id='$r[voyage_id]' ");
		  $bid = mysql_fetch_array($busid);
		 
		  
		 $bmodel=mysql_query("SELECT bus_model from bus WHERE    bus_id='$bid[bus_id]' ");
		  $bm = mysql_fetch_array($bmodel);
		
 
		 $result=mysql_query("select * from ticket where voyage_id= '$r[voyage_id]'");
		 
		  
		  
 while ($row = mysql_fetch_array($result)) {
	 
	 
  echo '<td><input type="radio" name="ticket[]" value="'.@$row[ticket_id].' "  required ></td>';
 echo"<td>".$row['time']."</td>";
 
  echo"<td>".$bm['bus_model']."</td>";
   echo"<td>".$row['amount']."</td>"; 
   
 echo "</tr>"; 
 
 }
 
 
 } 
   }
			 ?>   
			 
</table>


<input type="submit" name="busseats"   class="btn btn-info btn-lg" value="select"   > 

 </form>


</body>
</html>