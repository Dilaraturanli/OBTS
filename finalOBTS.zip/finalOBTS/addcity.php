<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>



<?php
if($_POST["add"]){

	$cityname=$_POST["cityname"];
	
	   include("database.php"); 
	   	
	   	   
         $sql = mysql_num_rows(mysql_query("SELECT * FROM city WHERE   city_name='$cityname' "));
		
		if ($sql==0){
		 mysql_query("insert into city(city_id,city_name) VALUES (NULL,'$cityname')");
		  header("location:addcity_index.php?msg=succes");
	    }
		
	   else{
		 header("location:addcity_index.php?msg=failed");
		
		
		}
		
		

	   
  
 
 }
?>