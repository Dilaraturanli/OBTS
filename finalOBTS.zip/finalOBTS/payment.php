<head>
<title>Online Bus Ticket System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script type='text/javascript' src='//code.jquery.com/jquery-1.8.3.js'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker3.min.css">
    <script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.min.js"></script>
        <link rel="stylesheet" href="css/bus.css">
  
</head>
<style>
body, html {
    height: 100%;
    background-repeat: no-repeat;
    background-image: url('back.jpg');
}

.div1 {
    background-color : gray;
    width: 200px;
    height: 80px;
    border: 3px solid black;
    box-sizing: border-box;
	float:right; 
}



</style>



<body>
  <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">Online Bus Ticket System</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                     <li class="active"><a href="mainPage.php">MainPage</a></li>   
                    </ul>
                 
				  
				   <ul class="nav navbar-nav navbar-right">
                        <?php
                        if(isset($_SESSION["login"]))
                        {
                               
                          ?>
                          <li>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span>
                                Welcome <b> <span class="caret"></span></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo $personalPageLink; ?>">Personal Page</a></li>
                                <li><a href="<?php echo $personalChangePass; ?>">Change Password</a></li>
                            </ul>
                          </li>
                          <li>
                            <a href="userlogout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
                          </li>
                          <?php
                        }
                     
                        ?>
                    </ul>
			</div>  
       </nav>



<?php							 

if($_POST["payment"] ){
 $ssn=$_POST["ssn"];
$length=$_POST["length"];
$seatnum=$_POST["seatnum"];
$lengtht=count($seatnum);



 $tamount=$_POST["tamount"];
	$name=$_POST["name"];
	$lastname=$_POST["lastname"];

	$ticket_id=$_POST["ticket_id"];
	   include("database.php"); 	 
 
 $time=mysql_query("select time from ticket where ticket_id= '$ticket_id'");
		$row = mysql_fetch_array($time);
		$t= $row[0];
$voyage=mysql_query("select voyage_id from ticket where ticket_id= '$ticket_id'");
		$row = mysql_fetch_array($voyage);
		$v= $row[0];
		
		
$start_id=mysql_query("select startingLocation from voyage where voyage_id= '$v'");
  $row = mysql_fetch_array($start_id);
		$sid= $row[0];
		
$start_name=mysql_query("select city_name from city where city_id= '$sid'");
  $row = mysql_fetch_array($start_name);
		$sn= $row[0];
		
		
$end_id=mysql_query("select destinationLocation from voyage where voyage_id= '$v'");
  $row = mysql_fetch_array($end_id);
		$eid= $row[0];
		
$end_name=mysql_query("select city_name from city where city_id= '$eid'");
  $row = mysql_fetch_array($end_name);
		$en= $row[0];
		
$date=mysql_query("select voyage_date from voyage where voyage_id= '$v'");
  $row = mysql_fetch_array($date);
		$d= $row[0];
		


		
}

?>


 <div class="form group">
  <form action='final.php ' method="post">
<div class="container" >
 <div class="panel panel-default">
        		<div class="panel-heading">
			    		<h3 class="panel-title">Ticket Informations</h3>
			 			</div>
						<div class="panel-body">
<table class="table  table-bordered" id="data">
 <thead>
 <tr>
 <th>Starting Location</th>
 <th>Destination Location</th>
 <th>Date</th>
 <th>Time</th> 
 <th>Total Amount</th> 

 </tr>
 </thead>
 <tbody>
 <tr>
 <?php	
echo"<td>".$sn."</td>";	  
echo"<td>".$en."</td>";
echo"<td>".$d."</td>";
echo"<td>".$t."</td>";
echo"<td>".$tamount."</td>";
  


echo "</tr>"; 
	   
	  

?>


</table>
<div class="div1"><h3>Total amount:<?php echo $tamount; ?></h3> </div>
<br><br><br>
<br>
<br>

 </div>
</div>
 </div>
</div>


<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        Payment Details
                    </h3>
                </div>
                <div class="panel-body">
                    <form role="form">
					
                    <div class="form-group">
					<form action='final.php' method="post">
					 <label for="userName">
                            USER NAME</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="userName" placeholder="User Name"
                                required autofocus />
                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        </div>
                         <br>
                        <label for="cardNumber">
                            CARD NUMBER</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="cardNumber" name="cardnumber" placeholder="Valid Card Number"
                                required autofocus />
                            <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-7 col-md-7">
                            <div class="form-group">
                                <label for="expityMonth">
                                   EXPIRY DATE</label><br>
                                <div class="col-xs-6 col-lg-6 pl-ziro">
                                    <input type="text" class="form-control" id="expityMonth" placeholder="MM" required />
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-xs-5 col-md-5 pull-right">
                            <div class="form-group">
                                <label for="cvCode">
                                    CV CODE</label>
                                <input type="password" class="form-control" id="cvCode" placeholder="CV" required />
								
                            </div>
                        </div>
                    </div>
             
                </div>
            </div>
          
            <br/>
			 <form action='final.php' method="post">
			 <input type="hidden" name="ticketid" value="<?php echo $ticket_id;?>">
			
			  <input type="hidden" name="length" value="<?php echo $length ?>">
			  <?php	

 
 for($i=0; $i<$lengtht;$i++){
	 ?>
	<input type="hidden" name="seatnum[]" value="<?php echo $seatnum[$i];?>">
	<input type="hidden" name="ssn[]" value="<?php echo $ssn[$i];?>">
	<?php
 }
?>
			  
            <input type="submit"  class="btn btn-success btn-lg btn-block" role="button" name="pay" value="Pay" >
		
			       </form>
          </div>
   
        
          <div class="col-md-6 col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        User Details
                    </h3>
                </div>
                <div class="panel-body">
				 <form role="form">
                    <div class="form-group">
					 <label for="mail">
                            USER MAIL</label>
                        <div class="input-group">
                            <input type="mail" class="form-control" id="mail" placeholder="mail"
                                required autofocus />
                             <span class="input-group-addon"> <span class="glyphicon glyphicon-envelope"></span></span>
                        </div>
                         <br>
                        <label for="phone">
                            USER PHONE</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="phone" placeholder="Phone"
                                required autofocus />
                            <span class="input-group-addon"><span class="glyphicon glyphicon-phone"></span></span>
                        </div>
                    </div>
					</div>
					</div>
				
			</div>
       </div>				
</div>
</div>  
</form>