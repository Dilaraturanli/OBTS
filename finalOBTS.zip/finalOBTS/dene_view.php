
<?php
if($_POST["button"]){
 $seat=$_POST["seat"];

	$length=count($seat);
	
	   include("database.php"); 
	   
	   echo $length;
}
?>


<div class="modal-footer" >
          <button type="button" name="payment"  class="btn btn-default"   data-dismiss="modal" onClick="window.location='payment_index.php'"> Payment</button>
        </div>