<?php 

include("database.php");
ob_start();
session_start();


if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}
?>

<?php
 
if($_POST["editvoyage"]){
 $voyage=$_POST["voyage"];
 	
	$v=mysql_query("SELECT * from voyage where voyage_id='$voyage[0]'");
		$sql=mysql_fetch_array($v);
		
  $id=mysql_query("SELECT * from voyage where  voyage_id='$sql[voyage_id]'");
 $id=mysql_fetch_array($id);
 $id=$id[0];

 $busmodel=mysql_query("SELECT * from bus where  bus_id='$sql[bus_id]'");
 $busmodel=mysql_fetch_array($busmodel);
  $busmodel=$busmodel[1];
 
 $startingLocation=mysql_query("SELECT * from city where city_id='$sql[startingLocation]'");
 $startingLocation=mysql_fetch_array($startingLocation);
 $startingLocation=$startingLocation[1];
 
 
 $destinationLocation=mysql_query("SELECT * from city where city_id='$sql[destinationLocation]'");
 $destinationLocation=mysql_fetch_array($destinationLocation);
 $destinationLocation=$destinationLocation[1];

 $voyagedate=mysql_query("SELECT * from voyage where  voyage_id='$sql[voyage_id]'");
 $voyagedate=mysql_fetch_array($voyagedate);
 $voyagedate=$voyagedate[4];


}
 ?> 

<title>Online Bus Ticket System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script type='text/javascript' src='//code.jquery.com/jquery-1.8.3.js'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker3.min.css">
    <script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
           <script src="js/jquery-1.12.3.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script type='text/javascript' src='//code.jquery.com/jquery-1.8.3.js'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker3.min.css">
    <script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.min.js"></script>
		
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script type='text/javascript' src='//code.jquery.com/jquery-1.8.3.js'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker3.min.css">
    <script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.min.js"></script>
<script type='text/javascript'>
$(function(){
$('.input-group.date').datepicker({
	  startDate: '+1d',
	  endDate: '+1m',
    calendarWeeks: true,
    todayHighlight: true,
    autoclose: true,

	
}); 


 
});

</script>
</head>


<style>
body, html {
    height: 100%;
    background-repeat: no-repeat;
    background-image: url('back.jpg');

    background-position: center;

    background-size: cover;
}
</style>
<body>
  <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home_index.php">Online Bus Ticket Admin System</a>
    </div>
	<div class="collapse navbar-collapse">
    <ul class="nav navbar-nav">
	   <li class="dropdown">
        <a class="dropdown-toggle" class="active" data-toggle="dropdown">Add
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="addvoyage_index.php">Voyage</a></li>
          <li><a href="addbus_index.php">Bus</a></li>
		  <li><a href="addticket_index.php">Ticket</a></li>
		  <li><a href="addcity_index.php">City</a></li>
        </ul>
      </li>
      <li class="dropdown">
	   <a class="dropdown-toggle" data-toggle="dropdown" >Delete
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
           <li><a href="deletevoyage_index.php">Voyage</a></li>
		  <li><a href="deletebus_index.php">Bus</a></li>
		  <li><a href="deleteticket_index.php">Ticket</a></li>

        </ul>
      </li>
	   <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" >Edit
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="editvoyage.php">Voyage</a></li>
        </ul>
      </li>
	    <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" >View
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="viewvoyage.php">Voyage</a></li>
		  <li><a href="viewticket.php">Ticket</a></li>
          <li><a href="viewbus.php">Bus</a></li>
		  <li><a href="viewcity.php">City</a></li>
        </ul>
      </li>
	  
	  
	   </ul>
    <ul class="nav navbar-nav navbar-right">
     
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
    </ul>
	

  </div>
</nav>
  <div class="form">
 
   <div class=" col-md-4 col-md-offset-4">
        	<div class="panel panel-default"  >
        		<div class="panel-heading">
			    		<h3 class="panel-title">Edit Voyage Form </h3>
			 			</div>
						<div class="panel-body">
			   
			   <div class="row">
							
			<?php
					$get=mysql_query("SELECT * FROM city ORDER BY city_id ASC");
$option = '';
 while($row = mysql_fetch_assoc($get))
{
  $option .= '<option value = "'.$row['city_id'].'">'.$row['city_name'].'</option>';
}
?>

			<?php
					$sql=mysql_query("SELECT * FROM bus ORDER BY bus_id ASC");
$optionbus = '';
 while($row = mysql_fetch_assoc($sql))
{
  $optionbus .= '<option value = "'.$row['bus_id'].'">'.$row['bus_model'].'</option>';
}
?>
						
						
						
	<form id="bootstrapSelectForm" method="post" class="form-horizontal" action="editv.php">
	
	 <div class="form-group"   >
	<label class="col-xs-3 control-label">Voyage ID</label>
					
	   <div class="col-xs-5 selectContainer">
	   <input readonly="readonly" type="text" name="voyageid" class="form-control" value="<?php echo $id ?>" >
	      </div>
    </div>
	
	   
    <div class="form-group"   >
        <label class="col-xs-3 control-label">Starting Location</label>
        <div class="col-xs-5 selectContainer">
			
	
            <select name="startinglocation" class="form-control"  style="width: 155%"   oninvalid="this.setCustomValidity('Please choose a starting city')"
 oninput="setCustomValidity('')"   required>
			<option selected disabled>  <?php echo $startingLocation ?>  </option>
                <?php echo $option; ?>
            </select>
        </div>
    </div>
	
	
	<div class="form-group" >
        <label class="col-xs-3 control-label">Destination Location</label>
        <div class="col-xs-5 selectContainer">
			
	     
            <select  name="destinationlocation" class="form-control"   style="width: 155%"  oninvalid="this.setCustomValidity('Please choose a destination city')"
 oninput="setCustomValidity('')"   required>
			<option selected disabled>  <?php echo $destinationLocation ?>  </option>
                <?php echo $option; ?>
            </select>
        </div>
    </div>

 <div class="form-group" >
        <label class="col-xs-3 control-label">Bus Model</label>
        <div class="col-xs-5 selectContainer">
			
	
            <select class="form-control"  name="bus" style="width: 155%"  oninvalid="this.setCustomValidity('Please choose a bus ')"
 oninput="setCustomValidity('')"   required>
			<option selected disabled> <?php echo $busmodel ?> </option>
                <?php echo $optionbus; ?>
            </select>
        </div>
    </div>
	
	 <div class="form-group" >
	 <label class="col-xs-3 control-label">Date of Voyage &nbsp;</label>
	 <div class="input-group date">
  <input type="text" class="form-control" name="date"   value="<?php echo $voyagedate ?>"  required> <span class="input-group-addon" style="width: 25%"><i class="glyphicon glyphicon-calendar" ></i></span>
</div>



	  </div>

	  
   
<div class="form-group" >
 <div class="col-sm-offset-8 col-sm-10">
   <input type="submit" name="editvoyage" class="btn btn-primary" value="Submit" >
   </div>
   </div>
              </div>
                </form>
            </div>
        </div>
    </div>
	</div>

	
</body>
</html>
 