<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>

<?php
if($_POST["deletevoyage"]){
 $voyageid=$_POST["voyageid"];
 
	$length=count($voyageid);
	
	   include("database.php"); 
	   
      for($i=0; $i<$length;$i++){
		 $ticket=mysql_query("DELETE FROM ticket WHERE voyage_id=$voyageid[$i] ");
		 $voyage=mysql_query("DELETE FROM voyage WHERE voyage_id=$voyageid[$i]");
	
	 }
	     header("location:deletevoyage_index");
		

    
 }
	