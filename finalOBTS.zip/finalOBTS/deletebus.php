<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>

<?php
if($_POST["deletebus"]){
 $busid=$_POST["busid"];
 
	$length1=count($busid);
	
	   include("database.php"); 
	   
	    $v=mysql_query("SELECT voyage_id FROM voyage WHERE bus_id='$busid[0]' ");
         while($voyage = mysql_fetch_assoc($v)){
			 $voyageid[]=$voyage["voyage_id"];
		 }	 

		 $length=mysql_num_rows($v);
		  
		  for($i=0;$i<$length;$i++){
			 $ticket=mysql_query("DELETE FROM ticket WHERE voyage_id=$voyageid[$i] ");
		 $voyage=mysql_query("DELETE FROM voyage WHERE voyage_id=$voyageid[$i]");
			 
		  }
		
		 for($i=0;$i<$length1;$i++){
		 
			   $bus=mysql_query("DELETE FROM bus WHERE bus_id=$busid[$i] ");
	
		 }
	
		 header("location:deletebus_index");

    
 }
	