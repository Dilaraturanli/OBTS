<?php 

include("database.php");
ob_start();
session_start();


?>
<html>
<head>
<title>Online Bus Ticket System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
         <script src="js/jquery-1.12.3.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script type='text/javascript' src='//code.jquery.com/jquery-1.8.3.js'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker3.min.css">
    <script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.min.js"></script>
<script type='text/javascript'>
$(function(){
$('.input-group.date').datepicker({
	  startDate: '+1d',
	  endDate: '+1m',
    calendarWeeks: true,
    todayHighlight: true,
    autoclose: true,

	
}); 


 
});

</script>
  
</head>
	
	
	

	
	
	
	
<style>
body, html {
    height: 100%;
    background-repeat: no-repeat;
    background-image: url('back.jpg');

    background-position: center;

    background-size: cover;
}
div.slide{
    padding-top: 50px;
    padding-right: 30px;
    padding-bottom: 10px;
    padding-left: 80px;
}	


</style>
    <body>
        <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">Online Bus Ticket System</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                     <li class="active"><a href="mainPage.php">MainPage</a></li>   
                    </ul>
					
				  
				   <ul class="nav navbar-nav navbar-right">
                        <?php
                        if(isset($_SESSION["login"]))
                        {
                               
                          ?>
                          <li>
                            <a class="dropdown-toggle" data-toggle="dropdown" ><span class="glyphicon glyphicon-user"></span>
                                Welcome <b> <span class="caret"></span></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="seemyticket.php">See Ticket</a></li>
                                <li><a href="">See Booking</a></li>
								<li><a href="">Edit Profil</a></li>
								
                            </ul>
                          </li>
                          <li>
                            <a href="userlogout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
                          </li>
                          <?php
                        }
                     
                        ?>
                    </ul>
			</div>  
       </nav>
	   <div class="container" >
 <div class="panel panel-default">
        		<div class="panel-heading">
			    		<h3 class="panel-title">Ticket List</h3>
			 			</div>
						<div class="panel-body">
<table class="table  table-bordered" id="data">
 <thead>
 <tr>

 <th>Ticket ID</th>
 <th>User SSN</th>
 <th>Seat No</th>
  
 </tr>
 </thead>
 <tbody>
 <tr>
 <?php
 
   include("database.php"); 
   
if(isset( $_SESSION["logged_user_username"]))
                        {
								   $name=$_SESSION["logged_user_username"];
 
						}
    
	    $id=mysql_query("SELECT registeruser_id from hasticket where username='$name'");
		
		  
		 $ticket=mysql_query("SELECT * from hasticket where user_ssn='43246553664'");
		
while($sql=mysql_fetch_array($ticket)){
 echo"<td>".$sql['ticket_id']."</td>";
 
 echo"<td>".$sql['user_ssn']."</td>";
 

 echo"<td>".$sql['seat_no']."</td>";

  
 echo "</tr>"; 
 
 }
 
 
?>
</table>
</div>
 </div>
 </div>
 </div>
 </div>
 