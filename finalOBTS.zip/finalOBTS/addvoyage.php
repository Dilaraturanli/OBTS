<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>



<?php
if($_POST["add"]){

	$bus=$_POST["bus"];
	$startlocation=$_POST["startinglocation"];
	$destinationlocation=$_POST["destinationlocation"];
	  if ($startlocation==$destinationlocation){
			 header("location:addvoyage_index.php?msg=failed2");
			 exit;
		}
	$date=$_POST["date"];
	$date = date('Y-m-d', strtotime(str_replace('-', '/', $date)));
	 

	   include("database.php"); 
	   	
	   	   
         $sql = mysql_num_rows(mysql_query("SELECT * FROM voyage WHERE   bus_id='$bus' AND  startingLocation='$startlocation'  AND destinationLocation='$destinationlocation' AND voyage_date='$date'"));
		
		if ($sql==0){
		 mysql_query("insert into voyage (voyage_id,bus_id,startingLocation,destinationLocation,voyage_date) VALUES (NULL,'$bus','$startlocation','$destinationlocation','$date')");
		  header("location:addvoyage_index.php?msg=succes");
	    }
		
	   else{
		 header("location:addvoyage_index.php?msg=failed");
		
		
		}
		
		

	   
  
 
 }
?>
