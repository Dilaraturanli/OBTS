<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>

<?php
if($_POST["deleteticket"]){
 $ticketid=$_POST["ticketid"];
 
	$length=count($ticketid);
	
	   include("database.php"); 
	   
      for($i=0; $i<$length;$i++){
		 $ticket=mysql_query("DELETE FROM ticket WHERE ticket_id=$ticketid[$i] ");
	
	 }
	     header("location:deleteticket_index");
		

    
 }
	