<?php 

include("database.php");
ob_start();
session_start();


?>
<html>
<head>
<title>Online Bus Ticket System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
         <script src="js/jquery-1.12.3.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script type='text/javascript' src='//code.jquery.com/jquery-1.8.3.js'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker3.min.css">
    <script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.min.js"></script>
<script type='text/javascript'>
$(function(){
$('.input-group.date').datepicker({
	  startDate: '+1d',
	  endDate: '+1m',
    calendarWeeks: true,
    todayHighlight: true,
    autoclose: true,

	
}); 


 
});

</script>
  
</head>
	
	
	

	
	
	
	
<style>
body, html {
    height: 100%;
    background-repeat: no-repeat;
    background-image: url('back.jpg');

    background-position: center;

    background-size: cover;
}
div.slide{
    padding-top: 50px;
    padding-right: 30px;
    padding-bottom: 10px;
    padding-left: 80px;
}	


</style>
    <body>
        <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">Online Bus Ticket System</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                     <li class="active"><a href="mainPage.php">MainPage</a></li>   
                    </ul>
					
				  
				   <ul class="nav navbar-nav navbar-right">
                        <?php
                        if(isset($_SESSION["login"]))
                        {
                               
                          ?>
                          <li>
                            <a class="dropdown-toggle" data-toggle="dropdown" ><span class="glyphicon glyphicon-user"></span>
                                Welcome <b> <span class="caret"></span></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="">See Ticket</a></li>
                                <li><a href="">See Booking</a></li>
								<li><a href="">Edit Profil</a></li>
								
                            </ul>
                          </li>
                          <li>
                            <a href="userlogout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
                          </li>
                          <?php
                        }
                     
                        ?>
                    </ul>
			</div>  
       </nav>
	   
	<div class="container" >
  <div class="row">
     <div class="col-md-4" style=" margin-top: 150px;   ">
	 
	 <button type="button" class="btn btn-success  btn-lg "  style=" margin-left: 300px;  padding-right: 40px;" onClick='location.href="userlogin_index.php"' >Login </button>
	  
	 </div>
  <div class="col-md-4"  style="   margin-top: 150px;">
  <form action="register_index.php"  method="Post">
  <button type="button"  class="btn btn-primary  btn-lg "  style=" margin-left: 200px;" onClick='location.href="register_index.php"' >Register</button>
  </form>
</div>

	   </div> 
	   </div> 
     
      <div class=" col-md-12 ">
   

	  <div class="form">
 
   <div class=" col-md-4">
        		<div class="panel panel-default" style="height:450px" >
        		<div class="panel-heading">
			    		<h3 class="panel-title">Voyages</h3>
			 			</div>
						<div class="panel-body">
			   
			   <div class="row">
							
			<?php
					$get=mysql_query("SELECT * FROM city ORDER BY city_id ASC");
$option = '';
 while($row = mysql_fetch_assoc($get))
{
  $option .= '<option value = "'.$row['city_id'].'">'.$row['city_name'].'</option>';
}
?>

						
						
						
	<form id="bootstrapSelectForm" method="post" class="form-horizontal" action="seeticket.php">


<?php
					  if (isset($_GET["msg"]) && $_GET["msg"] == 'failed2') {
						  ?>
						  <div class="alert alert-danger">
  <strong>ERROR!</strong> The startinglocation and destinationlocation can not be same.
</div>
<?php
                     
                             }
?>

<?php
					  if (isset($_GET["msg"]) && $_GET["msg"] == 'failed') {
						  ?>
						  <div class="alert alert-danger">
  <strong>ERROR!</strong> Selected voyage not found.
</div>
<?php
                     
                             }
?>

                     
    <div class="form-group"   >
        <label class="col-xs-3 control-label">Starting Location</label>
        <div class="col-xs-5 selectContainer">
			
	
            <select name="startinglocation" class="form-control"  style="width: 155%"   oninvalid="this.setCustomValidity('Please choose a starting city')"
 oninput="setCustomValidity('')"   required>>
			<option selected disabled>  </option>
                <?php echo $option; ?>
            </select>
        </div>
    </div>
	
	
	<div class="form-group" >
        <label class="col-xs-3 control-label">Destination Location</label>
        <div class="col-xs-5 selectContainer">
			
	     
            <select  name="destinationlocation" class="form-control"   style="width: 155%"  oninvalid="this.setCustomValidity('Please choose a destination city')"
 oninput="setCustomValidity('')"   required>
			<option selected disabled>  </option>
                <?php echo $option; ?>
            </select>
        </div>
    </div>

	
	 <div class="form-group" >
	 <label class="col-xs-3 control-label">Date of Voyage &nbsp;</label>
	 <div class="input-group date">
  <input type="text" class="form-control" name="date"    required> <span class="input-group-addon" style="width: 25%"><i class="glyphicon glyphicon-calendar" ></i></span>
</div>



	  </div>
  
   
<div class="form-group" >
 <div class="col-md-offset-8 col-sm-10">
   <input type="submit" name="buy" class="btn btn-primary" value="Buy Ticket" >
   
   </div>
   </div>

   
<div class="form-group" >
 <div class="col-md-offset-8 col-sm-10">
   <input type="submit" name="booking" class="btn btn-primary" value="Booking" >
   
   </div>
   </div>   

              </div>
                </form>
            </div>
        </div>
</div>



  <div id="myCarousel" class="carousel slide" data-ride="carousel" style="margin-left:750px; height:450px; margin-top:50px"  >
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">

      <div class="item active">
        <img src="1.png"  style="width:100%;">
        <div class="carousel-caption">
        </div>
      </div>

      <div class="item">
        <img src="2.png" style="width:100%;">
        <div class="carousel-caption">
   
        </div>
      </div>
    
      <div class="item">
        <img src="3.png"  style="width:100%;">
        <div class="carousel-caption">
          
        </div>
      </div>
  
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
	
		
	
	</div>
	
	
	
	
  </div>
</body>
</html>