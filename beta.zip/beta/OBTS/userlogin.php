<?php 

include("database.php");
ob_start();
session_start();

$username = $_POST['username'];
$password = $_POST['password'];


$sql_check = mysql_query("select * from registered_user where username='".$username."' and   password='".$password."' ") or die(mysql_error());

if(mysql_num_rows($sql_check))  {
    $_SESSION["login"] = "true";
    $_SESSION["logged_user_username"] = $username;
    $_SESSION["logged_user_password"] = $password;
	 
    header("Location:mainPage.php");
	
	
	
}
else {
 header("location:userlogin_index.php?msg=failed");
ob_end_flush();
}
?>