 
 <?php
 if($_POST["busseats"]){
    $ticket=$_POST["ticket"];

	$length=count($ticket);
	
	   include("database.php"); 
	   
	   $ticket_id=$ticket[0];
	   
	    $id=mysql_query("select voyage_id from ticket where ticket_id= '$ticket_id'");
		$row = mysql_fetch_array($id);
		$voyage_id= $row[0];
		
		$busid=mysql_query("select bus_id from voyage where voyage_id= '$voyage_id'");
		
		$r= mysql_fetch_array($busid);
		$bus_id= $r[0];
		
		$busmodel=mysql_query("select bus_model from bus where bus_id= '$bus_id'");
		$b= mysql_fetch_array($busmodel);
		$bus_model= $b[0];
		
		$time=mysql_query("select time from ticket where ticket_id= '$ticket_id'");
		$s = mysql_fetch_array($time);
		$t= $s[0];
		
		$amount=mysql_query("select amount from ticket where ticket_id= '$ticket_id'");
		$at = mysql_fetch_array($amount);
		$a= $at[0];
		
		
	    
 }	
	?>
	
<head>
<title>Online Bus Ticket System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script type='text/javascript' src='//code.jquery.com/jquery-1.8.3.js'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker3.min.css">
    <script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.min.js"></script>
        <link rel="stylesheet" href="css/bus.css">
  
</head>
<style>
body, html {
    height: 100%;
    background-repeat: no-repeat;
    background-image: url('back.jpg');
}
</style>



<body>
     <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">Online Bus Ticket System</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                     <li class="active"><a href="mainPage.php">MainPage</a></li>   
                    </ul>
                 
				  
				   <ul class="nav navbar-nav navbar-right">
                        <?php
                        if(isset($_SESSION["login"]))
                        {
                               
                          ?>
                          <li>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span>
                                Welcome <b> <span class="caret"></span></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo $personalPageLink; ?>">Personal Page</a></li>
                                <li><a href="<?php echo $personalChangePass; ?>">Change Password</a></li>
                            </ul>
                          </li>
                          <li>
                            <a href="userlogout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
                          </li>
                          <?php
                        }
                     
                        ?>
                    </ul>
			</div>  
       </nav>


<?php
if ($bus_model=="2-2"){?>

<div class="plane">

  <div class="cockpit">
    <h1>Please select a seat</h1>

  </div>
  <div class="exit exit--front fuselage">
    
  </div>
  
  <ol class="cabin fuselage"   >
  
  <div class="form-group">
  <form action="ticketinfo.php" method="post">				
    <li class="row row--1" >
      <ol class="seats" type="A" >
        <li class="seat" >
          <input type="checkbox" name="seat2[]"  value="1"  id="1" />
	  	   
          <label for="1">1</label>
        </li>
        <li class="seat">
          <input type="checkbox" name="seat2[]" value="2" id="2" />
          <label for="2">2</label>
        </li>
        <li class="seat">
          <input type="checkbox" name="seat2[]" value="3" id="3" />
          <label for="3">3</label>
        </li>
       
        <li class="seat">
          <input type="checkbox" name="seat2[]" value="4" id="4" />
          <label for="4">4</label>
        </li>
       
      </ol>
    </li>
    <li class="row row--2">
      <ol class="seats" type="A">
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  value="5"  id="5" />
          <label for="5">5</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  value="6"  id="6" />
          <label for="6">6</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  value="7"  id="7" />
          <label for="7">7</label>
        </li>
		
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  value="8"  id="8" />
          <label for="8">8</label>
        </li>
       
      </ol>
    </li>
    <li class="row row--3">
      <ol class="seats" type="A">
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  value="9"  id="9" />
          <label for="9">9</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]" value="10"  id="10" />
          <label for="10">10</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  value="11"  id="11" />
          <label for="11">11</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]" value="12"  id="12" />
          <label for="12">12</label>
        </li>
       
      </ol>
    </li>
    <li class="row row--4">
      <ol class="seats" type="A">
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  id="13" />
          <label for="13">13</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  id="14" />
          <label for="14">14</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  id="15" />
          <label for="15">15</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  id="16" />
          <label for="16">16</label>
        </li>
    
      </ol>
    </li>
    <li class="row row--5">
      <ol class="seats" type="A">
        <li class="seat">
          <input type="checkbox"   name="seat2[]"  id="17" />
          <label for="17">17</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  id="18" />
          <label for="18">18</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  id="19" />
          <label for="19">19</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]" id="20" />
          <label for="20">20</label>
        </li>
      
      </ol>
    </li>
    <li class="row row--6">
      <ol class="seats" type="A">
        <li class="seat">
          <input type="checkbox"   name="seat2[]"  id="21" />
          <label for="21">21</label>
        </li>
        <li class="seat">
          <input type="checkbox"   name="seat2[]"  id="22" />
          <label for="22">22</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  id="23" />
          <label for="23">23</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  id="24" />
          <label for="24">24</label>
        </li>
        
      </ol>
    </li>
    <li class="row row--7">
      <ol class="seats" type="A">
        <li class="seat">
          <input type="checkbox"   name="seat2[]"   id="25" />
          <label for="25">25</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  id="26" />
          <label for="26">26</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]" id="27" />
          <label for="27">27</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  id="28" />
          <label for="28">28</label>
        </li>
       
      </ol>
    </li>
    <li class="row row--8">
      <ol class="seats" type="A">
        <li class="seat">
          <input type="checkbox"   name="seat2[]"  id="29" />
          <label for="29">29</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  id="30" />
          <label for="30">30</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  id="31" />
          <label for="31">31</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  id="32" />
          <label for="32">32</label>
        </li>
      
      </ol>
    </li>
    <li class="row row--9">
      <ol class="seats" type="A">
        <li class="seat">
          <input type="checkbox"  name="seat2[]" id="33" />
          <label for="33">33</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  id="34" />
          <label for="34">34</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]"  id="35" />
          <label for="35">35</label>
        </li>
        <li class="seat">
          <input type="checkbox"  name="seat2[]" id="36" />
          <label for="36">36</label>
        </li>
       
      </ol>
    </li>
    <li class="row row--10">
      <ol class="seats" type="A" >
        <li class="seat">
          <input type="checkbox" name='seat2[]' id="37"  />
          <label for="37">37</label>
        </li>
        <li class="seat">
          <input type="checkbox" name='seat2[]' id="38" />
          <label for="38">38</label>
        </li>
        <li class="seat">
          <input type="checkbox" name='seat2[]' id="39" />
          <label for="39">39</label>
        </li>
        <li class="seat">
          <input type="checkbox" name='seat2[]' id="40"  />
          <label for="40">40</label>
        </li>
       
	     
      </ol>
    </li>
  </ol>
  <div class="exit exit--back fuselage">
    
  </div>
 <form action='payment.php' method="post">
    
	  <input type="hidden" name="amount" value="<?php echo $a;?>">
	  <input type="hidden" name="ticket_id" value="<?php echo $ticket_id;?>">
	<input type="submit" name="continue" value="Continue" class="btn btn-info btn-block"  style="height:60px; width:100px; float: right">
	 </form>
</div>
	 
	   
	   
	
  </ol>
 
</div>
        
		
     
</body>

<?php	
}
?>

<?php
if ($bus_model=="1-2"){?>

       <div class="plane">
  <div class="cockpit">
    <h1>Please select a seat</h1>
  </div>
  <div class="exit exit--front fuselage">
    
  </div>
  
  <ol class="cabin fuselage">
  <div class="form-group">
  <form action="ticketinfo.php" method="post">	
    <li class="row row--1">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox"   name="seat2[]"  id="1" />
          <label for="1">1</label>
        </li>
        
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="2" />
          <label for="2">2</label>
        </li>
       
        <li class="seat2">
          <input type="checkbox"  name="seat2[]"id="3" />
          <label for="3">3</label>
        </li>
       
      </ol>
    </li>
	
    <li class="row row--2">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="4" />
          <label for="4">4</label>
        </li>
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="5" />
          <label for="5">5</label>
        </li>
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="6" />
          <label for="6">6</label>
        </li>
        
       
      </ol>
    </li>
    <li class="row row--3">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="7" />
          <label for="7">7</label>
        </li>
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="8" />
          <label for="8">8</label>
        </li>
        <li class="seat2">
          <input type="checkbox"  name="seat2[]" id="9" />
          <label for="9">9</label>
        </li>
       
       
      </ol>
    </li>
    <li class="row row--4">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="10" />
          <label for="10">10</label>
        </li>
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="11" />
          <label for="11">11</label>
        </li>
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="12" />
          <label for="12">12</label>
        </li>
       
    
      </ol>
    </li>
    <li class="row row--5">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox"  name="seat2[]" id="13" />
          <label for="13">13</label>
        </li>
        <li class="seat2">
          <input type="checkbox"  name="seat2[]" id="14" />
          <label for="14">14</label>
        </li>
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="15" />
          <label for="15">15</label>
        </li>
       
      
      </ol>
    </li>
    <li class="row row--6">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="16" />
          <label for="16">16</label>
        </li>
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="17" />
          <label for="17">17</label>
        </li>
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="18" />
          <label for="18">18</label>
        </li>
        
      </ol>
    </li>
    <li class="row row--7">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" name="seat2[]"id="19" />
          <label for="19">19</label>
        </li>
        <li class="seat2">
          <input type="checkbox" name="seat2[]"  id="20" />
          <label for="20">20</label>
        </li>
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="21" />
          <label for="21">21</label>
        </li>
        
       
      </ol>
    </li>
    <li class="row row--8">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="22" />
          <label for="22">22</label>
        </li>
        <li class="seat2">
          <input type="checkbox" name="seat2[]"id="23" />
          <label for="23">23</label>
        </li>
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="24" />
          <label for="24">24</label>
        </li>
      
      
      </ol>
    </li>
    <li class="row row--9">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="25" />
          <label for="25">25</label>
        </li>
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="26" />
          <label for="26">26</label>
        </li>
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="27" />
          <label for="27">27</label>
        </li>
        
       
      </ol>
    </li>
    <li class="row row--10">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" name="seat2[]" id="28" />
          <label for="28">28</label>
        </li>
        <li class="seat2">
          <input type="checkbox" name="seat2[]"  id="29" />
          <label for="29">29</label>
        </li>
        <li class="seat2">
          <input type="checkbox" name="seat2[]"  id="30" />
          <label for="30">30</label>
        </li>
        
       
      </ol>
    </li>
  </ol>
  <div class="exit exit--back fuselage">
    
  </div>
 <form action='payment.php' method="post">
    
	  <input type="hidden" name="amount" value="<?php echo $a;?>">
	  <input type="hidden" name="ticket_id" value="<?php echo $ticket_id;?>">
	<input type="submit" name="continue" value="Continue" class="btn btn-info btn-block"  style="height:60px; width:100px; float: right">
	 </form>
</div>
	 
	   
	   
	
  </ol>
 
</div>

</body>

<?php
}
?>	
	