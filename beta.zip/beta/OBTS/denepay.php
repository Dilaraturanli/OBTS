<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>



<head>
<title>Online Bus Ticket System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script type='text/javascript' src='//code.jquery.com/jquery-1.8.3.js'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker3.min.css">
    <script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.min.js"></script>
        <link rel="stylesheet" href="css/bus.css">
  
</head>
<style>
body, html {
    height: 100%;
    background-repeat: no-repeat;
    background-image: url('back.jpg');
}
</style>



<body>
 <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home_index.php">Online Bus Ticket System</a>
    </div>
	<div class="collapse navbar-collapse">
    <ul class="nav navbar-nav">
	   </ul>
	 <ul class="nav navbar-nav navbar-right">
     
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
    </ul>
  </div>
</nav>

<div class="container" >
 <div class="form group">
   <form action="payment_index.php" method="POST">
<table class="table  table-bordered" id="data">
 <thead>
 <tr>
 <th>Voyage Time</th>
 <th>Bus Type</th>
 <th>Amount</th>
  <th>  </th>
 </tr>
 </thead>
 <tbody>
 <tr>
 <?php
 
   include("database.php"); 
   
   if($_POST["buy"]){
          $startlocation=$_POST["startinglocation"];
	$destinationlocation=$_POST["destinationlocation"];
	 if ($startlocation==$destinationlocation){
			 header("location:page1_index.php?msg=failed2");
			 exit;
		}
	$date=$_POST["date"];
	$date = date('Y-m-d', strtotime(str_replace('-', '/', $date)));
	   
	   $vid=mysql_query("SELECT voyage_id from voyage WHERE    startingLocation='$startlocation'  AND destinationLocation='$destinationlocation' AND voyage_date='$date'");
		  $length=count($vid);
		   if($length==0){
			    
   header("location:page1_index.php?msg=failed");
		   }
 while($r=mysql_fetch_array($vid)){
 
		
		 $busid=mysql_query("SELECT bus_id from voyage WHERE  voyage_id='$r[voyage_id]' ");
		  $bid = mysql_fetch_array($busid);
		 
		  
		 $bmodel=mysql_query("SELECT bus_model from bus WHERE    bus_id='$bid[bus_id]' ");
		  $bm = mysql_fetch_array($bmodel);
		
 
		 $result=mysql_query("select * from ticket where voyage_id= '$r[voyage_id]'");
		 
		  
		  
		  
 
             while ($row = mysql_fetch_array($result)) {
 echo '<td><input type="radio" name="tiket[]" value="'.@$row[ticket_id].'" ></td>';
 echo"<td>".$row['time']."</td>";
  echo"<td>".$bm['bus_model']."</td>";
   echo"<td>".$row['amount']."</td>";

 echo "</tr>"; 
			
 
   ?>
   
 
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal"  <?php  $b=$bm['bus_model']; if( $b=="1-2"){?> data-target="#myModal1" <?php  } ?> <?php if($b=="2-2"){?> data-target="#myModal2" <?php }
?> > Select seat</button>

</form>
</table>

 
 
 <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">BUS <?php echo $ticket[1];?></h4>
		  
        </div>
        <div class="modal-body">
           <div class="plane">
  <div class="cockpit">
    <h1>Please select a seat</h1>
  </div>
  <div class="exit exit--front fuselage">
    
  </div>
  
  <ol class="cabin fuselage">
    <li class="row row--1">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" id="1A" />
          <label for="1A">1A</label>
        </li>
        
        <li class="seat2">
          <input type="checkbox" id="1B" />
          <label for="1B">1B</label>
        </li>
       
        <li class="seat2">
          <input type="checkbox" id="1C" />
          <label for="1C">1C</label>
        </li>
       
      </ol>
    </li>
	
    <li class="row row--2">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" id="2A" />
          <label for="2A">2A</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="2B" />
          <label for="2B">2B</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="2C" />
          <label for="2C">2C</label>
        </li>
        
       
      </ol>
    </li>
    <li class="row row--3">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" id="3A" />
          <label for="3A">3A</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="3B" />
          <label for="3B">3B</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="3C" />
          <label for="3C">3C</label>
        </li>
       
       
      </ol>
    </li>
    <li class="row row--4">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" id="4A" />
          <label for="4A">4A</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="4B" />
          <label for="4B">4B</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="4C" />
          <label for="4C">4C</label>
        </li>
       
    
      </ol>
    </li>
    <li class="row row--5">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" id="5A" />
          <label for="5A">5A</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="5B" />
          <label for="5B">5B</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="5C" />
          <label for="5C">5C</label>
        </li>
       
      
      </ol>
    </li>
    <li class="row row--6">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" id="6A" />
          <label for="6A">6A</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="6B" />
          <label for="6B">6B</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="6C" />
          <label for="6C">6C</label>
        </li>
        
      </ol>
    </li>
    <li class="row row--7">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" id="7A" />
          <label for="7A">7A</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="7B" />
          <label for="7B">7B</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="7C" />
          <label for="7C">7C</label>
        </li>
        
       
      </ol>
    </li>
    <li class="row row--8">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" id="8A" />
          <label for="8A">8A</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="8B" />
          <label for="8B">8B</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="8C" />
          <label for="8C">8C</label>
        </li>
      
      
      </ol>
    </li>
    <li class="row row--9">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" id="9A" />
          <label for="9A">9A</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="9B" />
          <label for="9B">9B</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="9C" />
          <label for="9C">9C</label>
        </li>
        
       
      </ol>
    </li>
    <li class="row row--10">
      <ol class="seats2" type="A">
        <li class="seat2">
          <input type="checkbox" id="10A" />
          <label for="10A">10A</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="10B" />
          <label for="10B">10B</label>
        </li>
        <li class="seat2">
          <input type="checkbox" id="10C" />
          <label for="10C">10C</label>
        </li>
        
       
      </ol>
    </li>
  </ol>
  <div class="exit exit--back fuselage">
    
  </div>
</div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>

</body>
 
 

  <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">BUS <?php echo $b;?></h4>
        </div>
        <div class="modal-body">
		 
		 <form action="payment_index.php" method="POST">
           <div class="plane">
  <div class="cockpit">
    <h1>Please select a seat</h1>
  </div>
  <div class="exit exit--front fuselage">
    
  </div>
  
  <ol class="cabin fuselage"   >
  
  
  
  <div class="form-group">
  <form action="payment_index.php" method="post">		  				    
		
    <li class="row row--1">
      <ol class="seats" type="A">
        <li class="seat">
          <input type="checkbox"  id="A1" />
          <label for="A1">1A</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="B1" />
          <label for="B1">1B</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="C1" />
          <label for="C1">1C</label>
        </li>
       
        <li class="seat">
          <input type="checkbox" id="D1" />
          <label for="D1">1D</label>
        </li>
       
      </ol>
    </li>
    <li class="row row--2">
      <ol class="seats" type="A">
        <li class="seat">
          <input type="checkbox" id="A2" />
          <label for="A2">2A</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="B2" />
          <label for="B2">2B</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="C2" />
          <label for="C2">2C</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="D2" />
          <label for="D2">2D</label>
        </li>
       
      </ol>
    </li>
    <li class="row row--3">
      <ol class="seats" type="A">
        <li class="seat">
          <input type="checkbox" id="A3" />
          <label for="A3">3A</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="B3" />
          <label for="B3">3B</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="C3" />
          <label for="C3">3C</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="D3" />
          <label for="D3">3D</label>
        </li>
       
      </ol>
    </li>
    <li class="row row--4">
      <ol class="seats" type="A">
        <li class="seat">
          <input type="checkbox" id="A4" />
          <label for="A4">4A</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="B4" />
          <label for="B4">4B</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="C4" />
          <label for="C4">4C</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="D4" />
          <label for="D4">4D</label>
        </li>
    
      </ol>
    </li>
    <li class="row row--5">
      <ol class="seats" type="A">
        <li class="seat">
          <input type="checkbox" id="A5" />
          <label for="A5">5A</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="B5" />
          <label for="B5">5B</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="C5" />
          <label for="C5">5C</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="D5" />
          <label for="D5">5D</label>
        </li>
      
      </ol>
    </li>
    <li class="row row--6">
      <ol class="seats" type="A">
        <li class="seat">
          <input type="checkbox" id="6A" />
          <label for="6A">6A</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="6B" />
          <label for="6B">6B</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="6C" />
          <label for="6C">6C</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="6D" />
          <label for="6D">6D</label>
        </li>
        
      </ol>
    </li>
    <li class="row row--7">
      <ol class="seats" type="A">
        <li class="seat">
          <input type="checkbox" id="7A" />
          <label for="7A">7A</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="7B" />
          <label for="7B">7B</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="7C" />
          <label for="7C">7C</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="7D" />
          <label for="7D">7D</label>
        </li>
       
      </ol>
    </li>
    <li class="row row--8">
      <ol class="seats" type="A">
        <li class="seat">
          <input type="checkbox" id="8A" />
          <label for="8A">8A</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="8B" />
          <label for="8B">8B</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="8C" />
          <label for="8C">8C</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="8D" />
          <label for="8D">8D</label>
        </li>
      
      </ol>
    </li>
    <li class="row row--9">
      <ol class="seats" type="A">
        <li class="seat">
          <input type="checkbox" id="9A" />
          <label for="9A">9A</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="9B" />
          <label for="9B">9B</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="9C" />
          <label for="9C">9C</label>
        </li>
        <li class="seat">
          <input type="checkbox" id="9D" />
          <label for="9D">9D</label>
        </li>
       
      </ol>
    </li>
    <li class="row row--10">
      <ol class="seats" type="A" >
        <li class="seat">
          <input type="checkbox" name='seat[]' id="A10"  />
          <label for="A10">10A</label>
        </li>
        <li class="seat">
          <input type="checkbox" name='seat[]' id="B10" />
          <label for="B10">10B</label>
        </li>
        <li class="seat">
          <input type="checkbox" name='seat[]' id="C10" />
          <label for="C10">10C</label>
        </li>
        <li class="seat">
          <input type="checkbox" name='seat[]' id="D10"  />
          <label for="D10">10D</label>
        </li>
       
	     
      </ol>
    </li>
  </ol>
  <div class="exit exit--back fuselage">
    
  </div>
</div>
	 <div class="modal-footer" >
	<input type="submit" name="payment" value="Payment" class="btn btn-info btn-block"  style="height:60px; width:100px; float: right">
	
	   </div>
	   
	  
	 </form>
  </ol>
 
</div>
        </div>
		
      </div>
      
    </div>
  </div>
  
</div>
</body>

<?php
 }
   }  
 
   }


 ?>

</form>
</div>
</body>
</html>