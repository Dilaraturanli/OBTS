<head>
 <title>Online Exam System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
 <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" >Online Exam Admin System</a>
    </div>
	<div class="collapse navbar-collapse">
    <ul class="nav navbar-nav">
      <li class="active"><a href="home_index.php">Main Page</a></li>
	   <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="http://localhost/onlineexam/addUser.php">Add
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="adduser_index.php">User</a></li>
          <li><a href="addcourse_index.php">Course</a></li>
        </ul>
      </li>
      <li class="dropdown">
	   <a class="dropdown-toggle" data-toggle="dropdown" >Delete
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="deleteinstructor_index.php">Instructor</a></li>
		  <li><a href="deletestudent_index.php">Student</a></li>
          <li><a href="deletecourse_index.php">Course</a></li>
        </ul>
      </li>
	   <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" >Edit
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="edituser_index.php">User</a></li>
          <li><a href="editcourse_index.php">Course</a></li>
        </ul>
      </li>
	    <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" >View
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="viewuser.php">User</a></li>
          <li><a href="viewcourse.php">Course</a></li>
        </ul>
      </li>
	   </ul>
	   <div class="form">
 
   <div class=" col-md-4 col-md-offset-4">
        	<div class="panel panel-default">
        		<div class="panel-heading">
			    		<h3 class="panel-title">Add User Form </h3>
			 			</div>
						<div class="panel-body">
			   
			   <div class="row">
	   
	   <div class="form-group">
                      <form action="dene_view.php" method="post">		  				    
		
						
<li class="row row--1">
      <ol class="seats"name="seat" type="A">
        <li class="seat" >
          <input type="checkbox"  name='seat[]' id="A1" />
          <label for="A1">1A</label>
        </li>
        <li class="seat">
          <input type="checkbox" name='seat[]'  id="B1" />
          <label for="B1">1B</label>
        </li>
        <li class="seat">
          <input type="checkbox" name='seat[]'  id="C1" />
          <label for="C1">1C</label>
        </li>
       
        <li class="seat">
          <input type="checkbox" name='seat[]'   id="D1" />
          <label for="D1">1D</label>
        </li>
       
      </ol>
    </li>
	 <input type="submit" name="button" value="submit" class="btn btn-info btn-block">
	
	   </div>
                </form>
            </div>
        </div>
    </div>
	</div>

	
</body>
</html>