<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
	
}

?>
<?php
if($_POST["button2"]){
   $coursename=$_POST["coursename"];
   $coursecode=$_POST["coursecode"];
    $coursecredit=$_POST["coursecredit"];
	   include("database.php"); 
  $sql = mysql_num_rows(mysql_query("select course_code from course where course_code='$coursecode'"));
		if ($sql > 0){
			echo "<center><u><b>ERROR!The course has already been added </b></u><br><a href=addcourse_index.php>Turn Back</a></center>";}

 else{
	 mysql_query("insert into course (course_id,course_name,course_code,course_credit) VALUES (NULL,'$coursename','$coursecode','$coursecredit')");
	 echo "<center><u><b>The course successfully added</b></u><br><a href=addcourse_index.php>Turn Back</a></center>";
	 
 }
}
?>