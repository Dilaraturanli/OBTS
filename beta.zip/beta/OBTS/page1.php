<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>



<?php
if($_POST["buy"]){

	$startlocation=$_POST["startinglocation"];
	$destinationlocation=$_POST["destinationlocation"];
	  if ($startlocation==$destinationlocation){
			 header("location:page1_index.php?msg=failed2");
			 exit;
		}
	$date=$_POST["date"];
	$date = date('Y-m-d', strtotime(str_replace('-', '/', $date)));
	 

	   include("database.php"); 
	   	
	   	   
         $sql = mysql_num_rows(mysql_query("SELECT * FROM voyage WHERE    startingLocation='$startlocation'  AND destinationLocation='$destinationlocation' AND voyage_date='$date'"));
		
		if ($sql==0){
		  header("location:page2.php");
	    }
		
	   
		
		

	   
  
 
 }
?>