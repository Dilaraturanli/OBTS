<?php 

include("database.php");
ob_start();
session_start();

?>



<?php
if($_POST["register"]){
	$first_name=$_POST["first_name"];
	$ssn=$_POST["ssn"];
	$last_name=$_POST["last_name"];
	$user_password=$_POST["user_password"];
	$email=$_POST["email"];
	$contact_no=$_POST["contact_no"];
	

	   include("database.php"); 
	   	
	   	   
         $sql = mysql_num_rows(mysql_query("SELECT * FROM user WHERE   ssn='$ssn'"));
		
		if ($sql==0){
		 mysql_query("insert into user (user_id,ssn,user_name,user_surname,user_phone,user_email,user_role) VALUES (NULL,'$ssn','$first_name','$last_name','$contact_no','$email',1)");
		  mysql_query("insert into registered_user  (registeruser_id,username,password,point,user_role) VALUES (NULL,'$first_name','$user_password',0,1)");
		  header("location:userlogin_index.php");
	    }
		
	   else{
		 header("location:register_index.php?msg=failed");
		
		
		}
		
		

	   
  
 
 }
 ?>