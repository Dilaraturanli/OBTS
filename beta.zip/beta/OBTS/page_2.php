<html>
    <head>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script type='text/javascript' src='//code.jquery.com/jquery-1.8.3.js'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker3.min.css">
    <script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.min.js"></script>
  </head>
  <body>

<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>


 
        <?php
		if($_POST["buy"]){
          $startlocation=$_POST["startinglocation"];
	$destinationlocation=$_POST["destinationlocation"];
	$date=$_POST["date"];
	$date = date('Y-m-d', strtotime(str_replace('-', '/', $date)));
	 
	   include("database.php"); 
	   	
	   	   
         $vid=mysql_query("SELECT voyage_id from voyage WHERE    startingLocation='$startlocation'  AND destinationLocation='$destinationlocation' AND voyage_date='$date'");
		 $r = mysql_fetch_array($vid);
		 $i=$r[0];

		 
		 $result=mysql_query("select * from ticket where voyage_id= '$i'");
		 
		 
 
            while ($row = mysql_fetch_array($result)) {
                // Print out the contents of the entry 
                echo '<tr>';
                echo '<td>' . $row['ticket_id'] . '</td>';
                echo '</tr>';
                
            }
		}
            ?>      

    <div class="container">
    
    <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
      <thead>
        <tr>
					<th>Book ID</th>
					<th>Book ISBN</th>
					<th>Book Title</th>
					<th>Book Author</th>
					<th>Book Category</th>
 
          <th style="width:125px;">Action
          </p></th>
        </tr>
      </thead>
      <tbody>
                   
				  <tr>
					 
						 <td><?php echo  $row['ticket_id'] ;?></td>
				         
								
				 </tr>
				    
 
 
 
      </tbody>
	  </table>
	  </div>
      </body>
	  </html>  