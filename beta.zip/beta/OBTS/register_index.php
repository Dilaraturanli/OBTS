<head>
<title>Online Bus Ticket System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script type='text/javascript' src='//code.jquery.com/jquery-1.8.3.js'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker3.min.css">
    <script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.min.js"></script>

<style>
body, html {
    height: 100%;
    background-repeat: no-repeat;
    background-image: url('back.jpg');

    background-position: center;

    background-size: cover;
}



</style>

<body>
 <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home_index.php">Online Bus Ticket System</a>
    </div>
	

  </div>
</nav>








<div class="form" >
 
   <div class=" col-md-4 col-md-offset-4" >
        	<div class="panel panel-default"  >
        		<div class="panel-heading">
			    		<h3 class="panel-title">REGİSTER FORM</h3>
			 			</div>
						<div class="panel-body">
			   
			   <div class="row">
							
			

						
						
						
	<form id="bootstrapSelectForm" method="post" class="form-horizontal" action='register.php'>		 
 
 
 
<?php
					  if (isset($_GET["msg"]) && $_GET["msg"] == 'failed') {
						  ?>
						  <div class="alert alert-danger">
  <strong>Saving is unsuccessful!</strong> The user has been added.
</div>
<?php
                     
                             }
?>
                     
    <div class="form-group"  action='register.php' method="POST">
  <label class="col-md-4 control-label">User Name</label>  
  <div class="col-md-6 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input  name="first_name" placeholder="User Name" class="form-control"  type="text">
    </div>
  </div>
</div>

<!-- Text input-->

<div class="form-group"  action='register.php' method="POST">
  <label class="col-md-4 control-label" >SSN</label> 
    <div class="col-md-6 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input name="ssn" placeholder="SSN" class="form-control"  type="text">
    </div>
  </div>
</div>

<div class="form-group"  action='register.php' method="POST">
  <label class="col-md-4 control-label" >Last Name</label> 
    <div class="col-md-6 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input name="last_name" placeholder="Last Name" class="form-control"  type="text">
    </div>
  </div>
</div>

 

<div class="form-group"  action='register.php' method="POST">
  <label class="col-md-4 control-label" >Password</label> 
    <div class="col-md-6 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
  <input name="user_password" placeholder="Password" class="form-control"  type="password">
    </div>
  </div>
   
  
  
</div>



<!-- Text input-->
       <div class="form-group" action='register.php' method="POST">
  <label class="col-md-4 control-label">E-Mail</label>  
    <div class="col-md-6 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
  <input name="email" placeholder="E-Mail Address" class="form-control"  type="text">
    </div>
  </div>
</div>


<!-- Text input-->
       
<div class="form-group" action='register.php' method="POST">
  <label class="col-md-4 control-label">Contact No.</label>  
    <div class="col-md-6 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
  <input name="contact_no" placeholder="Phone" class="form-control" type="text">
    </div>
  </div>
</div>

<!-- Select Basic -->

<!-- Success message -->


<!-- Button -->
<div class="form-group">
<form action='register.php' method="POST">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-4"><br>
  <input type="submit" class="btn btn-primary  btn-lg " name="register" value="Register"  style=" margin-left: 200px;"></button>
   </div>
</div>

</fieldset>
</form>
            </div>
        </div>
    </div>
	</div>

	
</body>
</html>