<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>

<title>Online Bus Ticket System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<style>
body, html {
    height: 100%;
    background-repeat: no-repeat;
    background-image: url('bg.jpg');
}
</style>

<body>
 <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home_index.php">Online Bus Ticket Admin System</a>
    </div>
	<div class="collapse navbar-collapse">
    <ul class="nav navbar-nav">
	   <li class="dropdown" >
        <a class="dropdown-toggle"  data-toggle="dropdown">Add
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="adduser_index.php">Voyage</a></li>
          <li><a href="addcourse_index.php">Bus</a></li>
        </ul>
      </li>
      <li class="dropdown">
	   <a class="dropdown-toggle" data-toggle="dropdown" >Delete
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="deleteinstructor_index.php">Voyage</a></li>
		  <li><a href="deletestudent_index.php">Bus</a></li>

        </ul>
      </li>
	   <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" >Edit
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="edituser_index.php">Voyage</a></li>
        </ul>
      </li>
	    <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" >View
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="viewuser.php">Voyage</a></li>
          <li><a href="viewcourse.php">Bus</a></li>
		  <li><a href="viewuser.php">City</a></li>
        </ul>
      </li>
	   </ul>
    
	 <ul class="nav navbar-nav navbar-right">
     
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
    </ul>
  </div>
</nav>

  <div class="form">
 
   <div class=" col-md-4 col-md-offset-4">
        	<div class="panel panel-default"  >
        		<div class="panel-heading">
			    		<h3 class="panel-title">Add Voyage Form </h3>
			 			</div>
						<div class="panel-body">
			   
			   <div class="row">
							
			<?php
					$get=mysql_query("SELECT * FROM city ORDER BY city_id ASC");
$option = '';
 while($row = mysql_fetch_assoc($get))
{
  $option .= '<option value = "'.$row['city_id'].'">'.$row['city_name'].'</option>';
}
?>

			<?php
					$sql=mysql_query("SELECT * FROM bus ORDER BY bus_id ASC");
$optionbus = '';
 while($row = mysql_fetch_assoc($sql))
{
  $optionbus .= '<option value = "'.$row['bus_id'].'">'.$row['bus_model'].'</option>';
}
?>
						
						
						
	<form id="bootstrapSelectForm" method="post" class="form-horizontal" action="addvoyage.php">
	 <?php
	 if (isset($_GET["msg"]) && $_GET["msg"] == 'succes') {
						  ?>
						  <div class="alert alert-success">
						 
  <strong>Success!</strong> 
</div>
<?php
                     
                             }
?>

<?php
					  if (isset($_GET["msg"]) && $_GET["msg"] == 'failed2') {
						  ?>
						  <div class="alert alert-danger">
  <strong>ERROR!</strong> The startinglocation and destinationlocation can not be same.
</div>
<?php
                     
                             }
?>
<?php
					  if (isset($_GET["msg"]) && $_GET["msg"] == 'failed') {
						  ?>
						  <div class="alert alert-danger">
  <strong>The voyage is added!</strong> Please retry.
</div>
<?php
                     
                             }
?>
    <div class="form-group" >
        <label class="col-xs-3 control-label">Starting Location</label>
        <div class="col-xs-5 selectContainer">
			
	
            <select name="startinglocation" class="form-control"  style="width: 155%"  match="#inputPassword" data-match-error="Whoops, these don't match" >
			<option selected disabled>Choose one city</option>
                <?php echo $option; ?>
            </select>
        </div>
    </div>
	
	
	<div class="form-group" >
        <label class="col-xs-3 control-label">Destination Location</label>
        <div class="col-xs-5 selectContainer">
			
	
            <select name="destinationlocation" class="form-control"   style="width: 155%"  >
			<option selected disabled>Choose one city</option>
                <?php echo $option; ?>
            </select>
        </div>
    </div>

 <div class="form-group" >
        <label class="col-xs-3 control-label">Bus Model</label>
        <div class="col-xs-5 selectContainer">
			
	
            <select name="bus" class="form-control"   style="width: 155%">
			<option selected disabled>Choose one model</option>
                <?php echo $optionbus; ?>
            </select>
        </div>
    </div>
 
   
<div class="form-group" >
 <div class="col-sm-offset-8 col-sm-10">
   <input type="submit" name="add" class="btn btn-primary" value="Submit" >
   </div>
   </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
	</div>

	
</body>
</html>