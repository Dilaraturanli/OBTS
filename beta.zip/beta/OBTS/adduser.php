<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>



<?php
if($_POST["button"]){
   
	$bus=$_POST["bus"];
	$startlocation=$_POST["startinglocation"];
	$destinationlocation=$_POST["destinationlocation"];
	
	
	   include("database.php"); 
  //$sql = mysql_num_rows(mysql_query("select user_username from user where user_username='$username'"));
		//if ($sql > 0){
			//echo "<center><u><b>ERROR!The user has already been added </b></u><br><a href=adduser_index.php>Turn Back</a></center>";
			//}

 //else{

		 mysql_query("insert into voyage (voyage_id,bus_id,startingLocation,destinationLocation) VALUES (NULL,'$bus','$startlocation','$destinationlocation')");
		 
		 
	// }
	// echo "<center><u><b>The user successfully added</b></u><br><a href=adduser_index.php>Turn Back</a></center>";
 //}
	
  
 
 }
?>
