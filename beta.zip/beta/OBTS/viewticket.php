<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
	
}

?>
<title>Online Bus Ticket System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<style>
body, html {
    height: 100%;
    background-repeat: no-repeat;
    background-image: url('back.jpg');

    background-position: center;

    background-size: cover;
}
</style>
<body>
 <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home_index.php">Online Bus Ticket Admin System</a>
    </div>
	<div class="collapse navbar-collapse">
    <ul class="nav navbar-nav">
	   <li class="dropdown">
        <a class="dropdown-toggle" class="active" data-toggle="dropdown">Add
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="addvoyage_index.php">Voyage</a></li>
          <li><a href="addbus_index.php">Bus</a></li>
		  <li><a href="addticket_index.php">Ticket</a></li>
        </ul>
      </li>
      <li class="dropdown">
	   <a class="dropdown-toggle" data-toggle="dropdown" >Delete
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="deleteinstructor_index.php">Voyage</a></li>
		  <li><a href="deletestudent_index.php">Bus</a></li>

        </ul>
      </li>
	   <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" >Edit
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="edituser_index.php">Voyage</a></li>
        </ul>
      </li>
	    <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" >View
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="viewvoyage.php">Voyage</a></li>
		  <li><a href="viewticket.php">Ticket</a></li>
          <li><a href="viewbus.php">Bus</a></li>
		  <li><a href="viewcity.php">City</a></li>
        </ul>
      </li>
	   </ul>
    <ul class="nav navbar-nav navbar-right">
     
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
    </ul>
	

  </div>
</nav>

<div class="container" >
 <div class="panel panel-default">
        		<div class="panel-heading">
			    		<h3 class="panel-title">Ticket List</h3>
			 			</div>
						<div class="panel-body">
<table class="table  table-bordered" id="data">
 <thead>
 <tr>

 <th>Ticket ID</th>
 <th>Voyage ID</th>
 <th>Time</th>
  <th>Seat </th>
   <th>Amount</th>
 </tr>
 </thead>
 <tbody>
 <tr>
 <?php
 
   include("database.php"); 
   
   
          
	   
	   $ticket=mysql_query("SELECT * from ticket");
		  
		
while($sql=mysql_fetch_array($ticket)){
 echo"<td>".$sql['ticket_id']."</td>";
 
 echo"<td>".$sql['voyage_id']."</td>";
 

 echo"<td>".$sql['time']."</td>";

 echo"<td>".$sql['seat']."</td>";
 echo"<td>".$sql['amount']."</td>";
 
 
  
 echo "</tr>"; 
 
 }
 
 
?>
</table>
</div>
 </div>
 </div>
 </div>
 </div>
 
   