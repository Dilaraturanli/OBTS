-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 22 Ara 2017, 07:52:16
-- Sunucu sürümü: 5.7.19
-- PHP Sürümü: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `obts`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admininfo`
--

DROP TABLE IF EXISTS `admininfo`;
CREATE TABLE IF NOT EXISTS `admininfo` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(45) NOT NULL,
  `admin_password` varchar(45) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `admininfo`
--

INSERT INTO `admininfo` (`admin_id`, `admin_username`, `admin_password`) VALUES
(1, 'didat', '1234');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `booking`
--

DROP TABLE IF EXISTS `booking`;
CREATE TABLE IF NOT EXISTS `booking` (
  `booking_id` int(11) NOT NULL,
  `booking_date` date NOT NULL,
  `last_date` date NOT NULL,
  `ticket_id` int(11) NOT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `bus`
--

DROP TABLE IF EXISTS `bus`;
CREATE TABLE IF NOT EXISTS `bus` (
  `bus_id` int(11) NOT NULL AUTO_INCREMENT,
  `bus_model` varchar(50) NOT NULL,
  `numberofseats` int(11) NOT NULL,
  PRIMARY KEY (`bus_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `bus`
--

INSERT INTO `bus` (`bus_id`, `bus_model`, `numberofseats`) VALUES
(1, '1-2', 30),
(2, '2-2', 40);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `city`
--

DROP TABLE IF EXISTS `city`;
CREATE TABLE IF NOT EXISTS `city` (
  `city_id` int(11) NOT NULL AUTO_INCREMENT,
  `city_name` varchar(50) NOT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `city`
--

INSERT INTO `city` (`city_id`, `city_name`) VALUES
(1, 'Ankara'),
(2, 'Istanbul'),
(3, 'izmir'),
(4, 'akcakoca');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `creditcard`
--

DROP TABLE IF EXISTS `creditcard`;
CREATE TABLE IF NOT EXISTS `creditcard` (
  `card_id` int(11) NOT NULL AUTO_INCREMENT,
  `card_number` varchar(16) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `validTHRU` date NOT NULL,
  `cvc` int(3) NOT NULL,
  `limitamount` int(4) NOT NULL,
  PRIMARY KEY (`card_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `creditcard`
--

INSERT INTO `creditcard` (`card_id`, `card_number`, `user_name`, `user_id`, `validTHRU`, `cvc`, `limitamount`) VALUES
(1, '5210193022443005', 'dilara turanli', 3, '2017-12-31', 153, 1000),
(2, '4444444444444444', 'didar turanli', 1, '2017-12-28', 153, 1000);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hascard`
--

DROP TABLE IF EXISTS `hascard`;
CREATE TABLE IF NOT EXISTS `hascard` (
  `hascard_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `card_id` int(11) NOT NULL,
  PRIMARY KEY (`hascard_id`),
  KEY `user_id` (`user_id`),
  KEY `card_id` (`card_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hasticket`
--

DROP TABLE IF EXISTS `hasticket`;
CREATE TABLE IF NOT EXISTS `hasticket` (
  `hasticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `seat_no` int(11) NOT NULL,
  PRIMARY KEY (`hasticket_id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `hasticket`
--

INSERT INTO `hasticket` (`hasticket_id`, `ticket_id`, `user_id`, `seat_no`) VALUES
(3, 14, 1, 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `has_booking`
--

DROP TABLE IF EXISTS `has_booking`;
CREATE TABLE IF NOT EXISTS `has_booking` (
  `hasbooking_id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`hasbooking_id`),
  KEY `booking_id` (`booking_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `payment`
--

DROP TABLE IF EXISTS `payment`;
CREATE TABLE IF NOT EXISTS `payment` (
  `amount` int(11) NOT NULL,
  `card_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  KEY `card_id` (`card_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `registered_user`
--

DROP TABLE IF EXISTS `registered_user`;
CREATE TABLE IF NOT EXISTS `registered_user` (
  `registeruser_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(11) NOT NULL,
  `password` varchar(50) NOT NULL,
  `point` int(11) NOT NULL,
  `user_role` int(2) DEFAULT '1',
  PRIMARY KEY (`registeruser_id`),
  UNIQUE KEY `username` (`username`),
  KEY `user_role` (`user_role`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `registered_user`
--

INSERT INTO `registered_user` (`registeruser_id`, `username`, `password`, `point`, `user_role`) VALUES
(1, 'aysenur', '12345', 0, 1),
(2, 'dilo', '15165', 0, 1),
(3, 'can', '123456', 0, 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `role_id` int(2) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(45) NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `role`
--

INSERT INTO `role` (`role_id`, `role_name`) VALUES
(1, 'registereduser'),
(2, 'visitor');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ticket`
--

DROP TABLE IF EXISTS `ticket`;
CREATE TABLE IF NOT EXISTS `ticket` (
  `ticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `voyage_id` int(11) NOT NULL,
  `time` time NOT NULL,
  `seat` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY (`ticket_id`),
  KEY `voyage_id` (`voyage_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `ticket`
--

INSERT INTO `ticket` (`ticket_id`, `voyage_id`, `time`, `seat`, `amount`) VALUES
(1, 74, '06:00:00', 30, 0),
(2, 74, '10:00:00', 30, 0),
(3, 80, '04:00:00', 40, 0),
(4, 84, '07:00:00', 30, 45),
(5, 84, '13:00:00', 30, 45),
(6, 84, '05:00:00', 40, 45),
(9, 86, '18:00:00', 30, 50),
(10, 74, '00:00:02', 30, 50),
(11, 80, '00:00:02', 30, 60),
(12, 83, '21:00:00', 30, 70),
(13, 97, '17:00:00', 30, 50),
(14, 92, '05:00:00', 30, 70),
(15, 92, '14:00:00', 30, 50),
(16, 92, '18:00:00', 40, 70),
(17, 99, '06:00:00', 40, 80),
(18, 99, '10:00:00', 40, 80);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `ssn` varchar(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_surname` varchar(50) NOT NULL,
  `user_phone` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_role` int(2) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `ssn` (`ssn`),
  KEY `user_role` (`user_role`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `user`
--

INSERT INTO `user` (`user_id`, `ssn`, `user_name`, `user_surname`, `user_phone`, `user_email`, `user_role`) VALUES
(1, '39965202488', 'didar', 'turanli', '454656', 'did@hot.com', 1),
(3, '44444', 'dilara', 'turanli', '51865', 'dil@hot.com', 2),
(4, '39968202488', 'dilara', 'turanli', '3563245244', 'dilara-turanli@hotmail.com', 1),
(5, '43246553664', 'ayse', 'bayram', '561894566854', 'aysenur@hotmail.com', 1),
(6, '3155652658', 'ali', 'akin', '658959', 'a@hot.com', 1),
(7, '626596', 'can', 'ak', '11465631', 'c@hot.com', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `visitor`
--

DROP TABLE IF EXISTS `visitor`;
CREATE TABLE IF NOT EXISTS `visitor` (
  `visitor_id` int(11) NOT NULL,
  `role_id` int(2) NOT NULL DEFAULT '2',
  PRIMARY KEY (`visitor_id`),
  KEY `user_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `visitor`
--

INSERT INTO `visitor` (`visitor_id`, `role_id`) VALUES
(1, 2);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `voyage`
--

DROP TABLE IF EXISTS `voyage`;
CREATE TABLE IF NOT EXISTS `voyage` (
  `voyage_id` int(11) NOT NULL AUTO_INCREMENT,
  `bus_id` int(11) NOT NULL,
  `startingLocation` int(11) NOT NULL,
  `destinationLocation` int(11) NOT NULL,
  `voyage_date` date NOT NULL,
  PRIMARY KEY (`voyage_id`),
  KEY `starting_Location` (`startingLocation`),
  KEY `DestinationLocation` (`destinationLocation`),
  KEY `bus_id` (`bus_id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `voyage`
--

INSERT INTO `voyage` (`voyage_id`, `bus_id`, `startingLocation`, `destinationLocation`, `voyage_date`) VALUES
(74, 1, 1, 2, '2017-12-28'),
(80, 1, 1, 2, '2017-12-29'),
(83, 1, 1, 3, '2017-12-29'),
(84, 1, 2, 3, '2017-12-22'),
(85, 2, 2, 3, '2017-12-16'),
(86, 2, 1, 2, '2017-12-28'),
(87, 1, 2, 3, '2017-12-31'),
(88, 2, 3, 1, '2018-01-01'),
(89, 2, 1, 2, '2018-01-12'),
(90, 2, 3, 2, '2018-02-24'),
(91, 2, 1, 2, '2017-11-26'),
(92, 2, 1, 2, '2017-12-23'),
(93, 2, 2, 1, '2018-02-17'),
(94, 1, 3, 2, '2018-01-01'),
(95, 1, 1, 2, '2018-01-18'),
(96, 1, 1, 2, '2017-12-22'),
(97, 1, 2, 1, '2017-12-22'),
(98, 1, 3, 1, '2018-01-12'),
(99, 2, 4, 3, '2018-01-19');

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `hascard`
--
ALTER TABLE `hascard`
  ADD CONSTRAINT `hascard_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `hascard_ibfk_2` FOREIGN KEY (`card_id`) REFERENCES `creditcard` (`card_id`);

--
-- Tablo kısıtlamaları `hasticket`
--
ALTER TABLE `hasticket`
  ADD CONSTRAINT `hasticket_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `hasticket_ibfk_2` FOREIGN KEY (`ticket_id`) REFERENCES `ticket` (`ticket_id`);

--
-- Tablo kısıtlamaları `has_booking`
--
ALTER TABLE `has_booking`
  ADD CONSTRAINT `has_booking_ibfk_2` FOREIGN KEY (`booking_id`) REFERENCES `booking` (`booking_id`);

--
-- Tablo kısıtlamaları `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`card_id`) REFERENCES `creditcard` (`card_id`),
  ADD CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Tablo kısıtlamaları `registered_user`
--
ALTER TABLE `registered_user`
  ADD CONSTRAINT `registered_user_ibfk_1` FOREIGN KEY (`user_role`) REFERENCES `role` (`role_id`);

--
-- Tablo kısıtlamaları `ticket`
--
ALTER TABLE `ticket`
  ADD CONSTRAINT `ticket_ibfk_1` FOREIGN KEY (`voyage_id`) REFERENCES `voyage` (`voyage_id`);

--
-- Tablo kısıtlamaları `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`user_role`) REFERENCES `role` (`role_id`);

--
-- Tablo kısıtlamaları `visitor`
--
ALTER TABLE `visitor`
  ADD CONSTRAINT `visitor_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`);

--
-- Tablo kısıtlamaları `voyage`
--
ALTER TABLE `voyage`
  ADD CONSTRAINT `voyage_ibfk_1` FOREIGN KEY (`bus_id`) REFERENCES `bus` (`bus_id`),
  ADD CONSTRAINT `voyage_ibfk_2` FOREIGN KEY (`startingLocation`) REFERENCES `city` (`city_id`),
  ADD CONSTRAINT `voyage_ibfk_3` FOREIGN KEY (`destinationLocation`) REFERENCES `city` (`city_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
